"""Environment-driven configuration.

Everything is optional so the Phase 0 skeleton boots without a Supabase project
or any API key. Later phases read these; nothing here connects or calls out.
"""

from __future__ import annotations

from functools import lru_cache

from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    # ── Supabase (create the project in ap-south-1 for data residency) ──
    supabase_url: str | None = None
    supabase_service_key: str | None = None
    supabase_anon_key: str | None = None

    # ── LLM (provider-agnostic; see providers.py) ──
    llm_provider: str = "claude"           # claude | openai | gemini
    llm_model: str | None = None
    anthropic_api_key: str | None = None
    openai_api_key: str | None = None
    gemini_api_key: str | None = None
    google_api_key: str | None = None      # alias for gemini_api_key

    @property
    def supabase_configured(self) -> bool:
        return bool(self.supabase_url and self.supabase_service_key)


@lru_cache
def get_settings() -> Settings:
    return Settings()
