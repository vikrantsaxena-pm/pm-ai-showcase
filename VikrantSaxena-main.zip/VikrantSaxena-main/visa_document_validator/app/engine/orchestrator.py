"""Orchestration + cascade invalidation (BUILD_SPEC §4 request-time, §6 Gap 3).

Resolves the ruleset by planned_visit_date, builds the evaluation context from
the session's uploaded documents, runs every applicable check, and persists
results. On re-upload it marks stale + re-runs EXACTLY the checks that consume
the re-uploaded document, and nothing else. No LLM, no hard-coded values.
"""

from __future__ import annotations

from dataclasses import dataclass, field

from .models import (
    BLOCKED,
    CheckResult,
    Context,
    Session,
    SessionDocument,
    TripFacts,
)
from .primitives import PRIMITIVES, _date
from .repository import Repository


class NoRulesetError(RuntimeError):
    """No in-force ruleset for the session (invariant 2 — say so, don't guess)."""


@dataclass
class ReuploadResult:
    rerun_keys: set[str]
    stale_result_ids: list[str]
    new_results: list[CheckResult] = field(default_factory=list)


def _trip_facts(session: Session) -> TripFacts:
    it = session.itinerary or {}
    entries = it.get("entries", [])
    days = sum(int(e.get("nights", 0)) for e in entries) if entries else it.get("days")
    entry_country = entries[0]["country"] if entries else None
    return TripFacts(
        start_date=_date(it.get("start_date")),
        end_date=_date(it.get("end_date")),
        days=days,
        entry_country=entry_country,
        stated_consulate=it.get("stated_consulate"),
        itinerary=entries,
    )


def build_context(session: Session, docs_by_type: dict[str, SessionDocument], today) -> Context:
    return Context(
        documents={dtype: doc.extracted for dtype, doc in docs_by_type.items()},
        trip=_trip_facts(session),
        today=today,
    )


def _needed_documents(check) -> set[str]:
    needed = set(check.depends_on_documents or [])
    if check.document_type:
        needed.add(check.document_type)
    return needed


def evaluate_check(check, ctx: Context, docs_by_type: dict[str, SessionDocument], session: Session) -> CheckResult:
    doc = docs_by_type.get(check.document_type)
    missing = sorted(d for d in _needed_documents(check) if d not in ctx.documents)
    if missing:
        return CheckResult(
            session_id=session.id, check_id=check.id, check_key=check.check_key,
            document_id=doc.id if doc else None, verdict=BLOCKED,
            expected_value={"missing_documents": missing}, citation=check.citation,
        )
    outcome = PRIMITIVES[check.check_type](check, ctx)
    return CheckResult(
        session_id=session.id, check_id=check.id, check_key=check.check_key,
        document_id=doc.id if doc else None, verdict=outcome.verdict,
        extracted_value=outcome.extracted_value, expected_value=outcome.expected_value,
        citation=outcome.citation,
    )


def run_session_checks(repo: Repository, session: Session, today) -> list[CheckResult]:
    ruleset = repo.resolve_ruleset(session.jurisdiction, session.purpose, session.planned_visit_date)
    if ruleset is None:
        raise NoRulesetError(
            f"No in-force ruleset for jurisdiction={session.jurisdiction!r}, "
            f"purpose={session.purpose!r}, date={session.planned_visit_date}."
        )
    checks = repo.list_checks(ruleset.id)
    docs_by_type = {d.document_type: d for d in repo.list_active_documents(session.id)}
    ctx = build_context(session, docs_by_type, today)
    results = [evaluate_check(c, ctx, docs_by_type, session) for c in checks]
    repo.save_results(results)
    return results


def reupload_document(
    repo: Repository, session: Session, document_type: str, extracted: dict,
    today, confidence: float | None = None,
) -> ReuploadResult:
    """§6 Gap 3: supersede the doc, invalidate + re-run exactly the dependent checks."""
    repo.add_document(SessionDocument(
        id=None, session_id=session.id, document_type=document_type,
        extracted=extracted, extraction_confidence=confidence,
    ))

    ruleset = repo.resolve_ruleset(session.jurisdiction, session.purpose, session.planned_visit_date)
    if ruleset is None:
        raise NoRulesetError("No in-force ruleset for re-upload.")
    checks = repo.list_checks(ruleset.id)

    # A check depends on D if D is its own document or is listed in depends_on_documents.
    dependent = [
        c for c in checks
        if c.document_type == document_type or document_type in (c.depends_on_documents or [])
    ]
    dependent_ids = {c.id for c in dependent}

    existing = repo.list_results(session.id, include_stale=True)
    stale_ids = [r.id for r in existing if r.check_id in dependent_ids and not r.stale]
    repo.mark_results_stale(stale_ids)

    docs_by_type = {d.document_type: d for d in repo.list_active_documents(session.id)}
    ctx = build_context(session, docs_by_type, today)
    new_results = [evaluate_check(c, ctx, docs_by_type, session) for c in dependent]
    repo.save_results(new_results)

    return ReuploadResult(
        rerun_keys={c.check_key for c in dependent},
        stale_result_ids=stale_ids,
        new_results=new_results,
    )


def verdict_map(results: list[CheckResult]) -> dict[str, str]:
    """Latest (non-stale) verdict per check_key — for assertions/reporting."""
    out: dict[str, str] = {}
    for r in results:
        if not r.stale:
            out[r.check_key] = r.verdict
    return out
