"""Repository interface + in-memory implementation.

Abstracts data access so the whole engine + eval set run offline against
fixture rows. The Supabase-backed implementation lands in a later phase and
implements the same interface — no engine code changes.

Rule data (rulesets/checks/requirements) is read-only here. Session state
(documents/results) is written during a session and by cascade re-runs.
"""

from __future__ import annotations

import itertools
from abc import ABC, abstractmethod
from datetime import date

from .models import (
    Check,
    CheckResult,
    DocumentRequirement,
    Ruleset,
    Session,
    SessionDocument,
)


class Repository(ABC):
    # ── rule data ──
    @abstractmethod
    def add_ruleset(self, ruleset: Ruleset) -> None: ...

    @abstractmethod
    def add_check(self, check: Check) -> None: ...

    @abstractmethod
    def add_document_requirement(self, req: DocumentRequirement) -> None: ...

    @abstractmethod
    def resolve_ruleset(
        self, jurisdiction: str, purpose: str, planned_visit_date: date
    ) -> Ruleset | None:
        """§4 request-time resolution: effective-dated, in_force."""

    @abstractmethod
    def list_checks(self, ruleset_id: str) -> list[Check]:
        """Effective checks including inherited parent checks (child overrides)."""

    @abstractmethod
    def list_document_requirements(self, ruleset_id: str) -> list[DocumentRequirement]:
        """Ordered by max_fix_lead_time_days DESC (§6 Gap 2)."""

    # ── session state ──
    @abstractmethod
    def add_session(self, session: Session) -> None: ...

    @abstractmethod
    def get_session(self, session_id: str) -> Session | None: ...

    @abstractmethod
    def add_document(self, doc: SessionDocument) -> SessionDocument:
        """Adds a document; supersedes any prior active doc of the same type."""

    @abstractmethod
    def list_active_documents(self, session_id: str) -> list[SessionDocument]: ...

    @abstractmethod
    def save_results(self, results: list[CheckResult]) -> None: ...

    @abstractmethod
    def list_results(self, session_id: str, include_stale: bool = True) -> list[CheckResult]: ...

    @abstractmethod
    def mark_results_stale(self, result_ids: list[str]) -> None: ...


class InMemoryRepository(Repository):
    def __init__(self) -> None:
        self._rulesets: dict[str, Ruleset] = {}
        self._checks: dict[str, list[Check]] = {}          # ruleset_id -> checks
        self._reqs: dict[str, list[DocumentRequirement]] = {}
        self._sessions: dict[str, Session] = {}
        self._documents: dict[str, list[SessionDocument]] = {}   # session_id -> docs
        self._results: dict[str, list[CheckResult]] = {}         # session_id -> results
        self._ids = itertools.count(1)

    def _next_id(self, prefix: str) -> str:
        return f"{prefix}_{next(self._ids)}"

    # ── rule data ──
    def add_ruleset(self, ruleset: Ruleset) -> None:
        self._rulesets[ruleset.id] = ruleset
        self._checks.setdefault(ruleset.id, [])
        self._reqs.setdefault(ruleset.id, [])

    def add_check(self, check: Check) -> None:
        self._checks.setdefault(check.ruleset_id, []).append(check)

    def add_document_requirement(self, req: DocumentRequirement) -> None:
        self._reqs.setdefault(req.ruleset_id, []).append(req)

    def resolve_ruleset(
        self, jurisdiction: str, purpose: str, planned_visit_date: date
    ) -> Ruleset | None:
        candidates = [
            r
            for r in self._rulesets.values()
            if r.jurisdiction == jurisdiction
            and r.purpose == purpose
            and r.status == "in_force"
            and r.effective_from <= planned_visit_date
            and (r.effective_to is None or r.effective_to > planned_visit_date)
        ]
        if not candidates:
            return None
        return max(candidates, key=lambda r: r.version)

    def list_checks(self, ruleset_id: str) -> list[Check]:
        # Walk parent lineage root→leaf; child checks override parent by check_key.
        lineage: list[Ruleset] = []
        cur = self._rulesets.get(ruleset_id)
        while cur is not None:
            lineage.append(cur)
            cur = self._rulesets.get(cur.parent_ruleset_id) if cur.parent_ruleset_id else None
        by_key: dict[str, Check] = {}
        for rs in reversed(lineage):                 # root first, leaf last (overrides win)
            for check in self._checks.get(rs.id, []):
                by_key[check.check_key] = check
        return list(by_key.values())

    def list_document_requirements(self, ruleset_id: str) -> list[DocumentRequirement]:
        lineage: list[Ruleset] = []
        cur = self._rulesets.get(ruleset_id)
        while cur is not None:
            lineage.append(cur)
            cur = self._rulesets.get(cur.parent_ruleset_id) if cur.parent_ruleset_id else None
        by_type: dict[str, DocumentRequirement] = {}
        for rs in reversed(lineage):
            for req in self._reqs.get(rs.id, []):
                by_type[req.document_type] = req
        return sorted(by_type.values(), key=lambda r: r.max_fix_lead_time_days, reverse=True)

    # ── session state ──
    def add_session(self, session: Session) -> None:
        self._sessions[session.id] = session
        self._documents.setdefault(session.id, [])
        self._results.setdefault(session.id, [])

    def get_session(self, session_id: str) -> Session | None:
        return self._sessions.get(session_id)

    def add_document(self, doc: SessionDocument) -> SessionDocument:
        if doc.id is None:
            doc.id = self._next_id("doc")
        docs = self._documents.setdefault(doc.session_id, [])
        for prior in docs:
            if prior.document_type == doc.document_type and prior.status == "uploaded":
                prior.status = "superseded"
                prior.superseded_by = doc.id
        docs.append(doc)
        return doc

    def list_active_documents(self, session_id: str) -> list[SessionDocument]:
        return [d for d in self._documents.get(session_id, []) if d.status == "uploaded"]

    def save_results(self, results: list[CheckResult]) -> None:
        for r in results:
            if r.id is None:
                r.id = self._next_id("res")
        self._results.setdefault(results[0].session_id if results else "", []).extend(results)

    def list_results(self, session_id: str, include_stale: bool = True) -> list[CheckResult]:
        rs = self._results.get(session_id, [])
        return rs if include_stale else [r for r in rs if not r.stale]

    def mark_results_stale(self, result_ids: list[str]) -> None:
        wanted = set(result_ids)
        for results in self._results.values():
            for r in results:
                if r.id in wanted:
                    r.stale = True
