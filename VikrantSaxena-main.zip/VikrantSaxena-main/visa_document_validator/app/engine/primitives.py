"""The 8 check primitives (BUILD_SPEC §8) — pure Python, no LLM, no DB.

Each primitive takes a rule row (`Check`) and a `Context`, and returns a
`CheckOutcome` (verdict + extracted value + expected value + the rule's
citation). No threshold, list, or date rule is hard-coded — every value is read
from the rule row or computed from context via a small data-driven operand
resolver. Adding a jurisdiction is adding rows; the dispatch table never changes.

Safety rule (invariant 9): a missing/unparseable input is `indeterminate`,
never `pass`.
"""

from __future__ import annotations

import calendar
import re
from datetime import date, timedelta
from difflib import SequenceMatcher
from typing import Any

from .models import FAIL, INDETERMINATE, PASS, Check, CheckOutcome, Context


# ── value helpers ──────────────────────────────────────────────────────────
def _num(v: Any) -> float | None:
    if isinstance(v, bool):
        return None
    if isinstance(v, (int, float)):
        return float(v)
    return None


def _money(v: Any) -> tuple[float | None, str | None]:
    """Return (amount, currency). Accepts {'amount','currency'} or a bare number."""
    if isinstance(v, dict) and "amount" in v:
        return _num(v["amount"]), v.get("currency")
    n = _num(v)
    return n, None


def _date(v: Any) -> date | None:
    if isinstance(v, date):
        return v
    if isinstance(v, str):
        try:
            return date.fromisoformat(v.strip())
        except ValueError:
            return None
    return None


def _add_offset(d: date, years: int = 0, months: int = 0, days: int = 0) -> date:
    total = d.month - 1 + months
    year = d.year + years + total // 12
    month = total % 12 + 1
    day = min(d.day, calendar.monthrange(year, month)[1])
    return date(year, month, day) + timedelta(days=days)


_OPS = {
    ">=": lambda a, b: a >= b,
    "<=": lambda a, b: a <= b,
    "==": lambda a, b: a == b,
    ">": lambda a, b: a > b,
    "<": lambda a, b: a < b,
}


def _norm(s: str) -> str:
    return re.sub(r"[^A-Za-z0-9]", "", s).upper()


def _tokens(s: str) -> list[str]:
    return re.sub(r"[^A-Za-z0-9]+", " ", s).upper().split()


def _name_match(a: str, b: str, min_ratio: float) -> bool:
    na, nb = _tokens(a), _tokens(b)
    if na == nb:
        return True
    if set(na) <= set(nb) or set(nb) <= set(na):   # added/dropped middle name
        return True
    if len(na) == len(nb):                          # per-token: catches Rohan/Mohan
        return all(SequenceMatcher(None, x, y).ratio() >= min_ratio for x, y in zip(na, nb))
    return SequenceMatcher(None, " ".join(na), " ".join(nb)).ratio() >= min_ratio


def _resolve_operand(spec: Any, ctx: Context) -> Any:
    """Data-driven RHS: const | context path | date_offset | product | literal."""
    if isinstance(spec, dict):
        if "const" in spec:
            return spec["const"]
        if "context" in spec:
            return ctx.resolve(spec["context"])
        if "date_offset" in spec:
            cfg = spec["date_offset"]
            base = _date(_resolve_operand(cfg["of"], ctx))
            if base is None:
                return None
            return _add_offset(base, cfg.get("years", 0), cfg.get("months", 0), cfg.get("days", 0))
        if "product" in spec:
            a = _resolve_operand(spec["product"][0], ctx)
            b = _resolve_operand(spec["product"][1], ctx)
            am, ac = _money(a)
            bm, bc = _money(b)
            if am is None or bm is None:
                return None
            cur = ac or bc
            return {"amount": am * bm, "currency": cur} if cur else am * bm
        return spec   # literal dict, e.g. {'amount','currency'}
    return spec


def _out(verdict: str, extracted: Any, expected: Any, check: Check) -> CheckOutcome:
    return CheckOutcome(verdict=verdict, extracted_value=extracted,
                        expected_value=expected, citation=check.citation)


# ── primitives ─────────────────────────────────────────────────────────────
def threshold(check: Check, ctx: Context) -> CheckOutcome:
    lhs = ctx.resolve(check.field_path)
    rhs = _resolve_operand(check.params.get("rhs", check.value), ctx)
    op = _OPS.get(check.operator or ">=")
    if lhs is None or rhs is None:
        return _out(INDETERMINATE, lhs, rhs, check)

    ld, rd = _date(lhs), _date(rhs)
    if ld is not None and rd is not None:                       # date comparison
        return _out(PASS if op(ld, rd) else FAIL, ld.isoformat(), rd.isoformat(), check)

    la, lc = _money(lhs)
    ra, rc = _money(rhs)
    if la is None or ra is None:
        return _out(INDETERMINATE, lhs, rhs, check)
    if lc and rc and lc != rc:                                  # currency mismatch, no rate
        return _out(INDETERMINATE, lhs, rhs, check)
    return _out(PASS if op(la, ra) else FAIL, lhs, rhs, check)


def date_coverage(check: Check, ctx: Context) -> CheckOutcome:
    p = check.params
    a_start = _date(ctx.resolve(p["a_start"]))
    a_end = _date(ctx.resolve(p["a_end"]))
    b_start = _date(ctx.resolve(p.get("b_start", "trip.start_date")))
    b_end = _date(ctx.resolve(p.get("b_end", "trip.end_date")))
    tol = timedelta(days=int(p.get("tolerance_days", 0)))
    extracted = {"start": ctx.resolve(p["a_start"]), "end": ctx.resolve(p["a_end"])}
    expected = {"cover_start": ctx.resolve(p.get("b_start", "trip.start_date")),
                "cover_end": ctx.resolve(p.get("b_end", "trip.end_date")),
                "tolerance_days": p.get("tolerance_days", 0)}
    if None in (a_start, a_end, b_start, b_end):
        return _out(INDETERMINATE, extracted, expected, check)
    covered = a_start <= b_start + tol and a_end >= b_end - tol
    return _out(PASS if covered else FAIL, extracted, expected, check)


def set_membership(check: Check, ctx: Context) -> CheckOutcome:
    val = ctx.resolve(check.field_path)
    allowed = check.value or []
    mode = check.params.get("mode", "in")
    expected = {"allowed": allowed, "mode": mode}
    if val is None:
        return _out(INDETERMINATE, val, expected, check)
    if mode == "superset":
        if not isinstance(val, (list, tuple, set)):
            return _out(INDETERMINATE, val, expected, check)
        missing = set(allowed) - set(val)
        return _out(PASS if not missing else FAIL, val, {**expected, "missing": sorted(missing)}, check)
    return _out(PASS if val in allowed else FAIL, val, expected, check)


def presence(check: Check, ctx: Context) -> CheckOutcome:
    v = ctx.resolve(check.field_path)
    expected = "present and non-empty"
    if v is None:
        return _out(INDETERMINATE, v, expected, check)     # not extracted → cannot confirm
    empty = v is False or (isinstance(v, str) and v.strip() == "") or (
        isinstance(v, (list, dict, tuple)) and len(v) == 0
    )
    return _out(FAIL if empty else PASS, v, expected, check)


def cross_document_match(check: Check, ctx: Context) -> CheckOutcome:
    p = check.params
    left = ctx.resolve(p["left"])
    right = ctx.resolve(p["right"])
    mode = p.get("match", "exact")
    extracted = {"left": left, "right": right}
    expected = {"match": mode}
    if left is None or right is None:
        return _out(INDETERMINATE, extracted, expected, check)
    if mode == "name":
        ok = _name_match(str(left), str(right), float(p.get("min_ratio", 0.85)))
    else:
        ld, rd = _date(left), _date(right)
        ok = (ld == rd) if (ld is not None and rd is not None) else (_norm(str(left)) == _norm(str(right)))
    return _out(PASS if ok else FAIL, extracted, expected, check)


def derived_routing(check: Check, ctx: Context) -> CheckOutcome:
    itin = ctx.trip.itinerary
    if not itin:
        return _out(INDETERMINATE, None, None, check)
    totals: dict[str, int] = {}
    order: list[str] = []
    for e in itin:
        country = e.get("country")
        totals[country] = totals.get(country, 0) + int(e.get("nights", 0))
        if country not in order:
            order.append(country)
    maxn = max(totals.values())
    computed = next(c for c in order if totals[c] == maxn)   # tie → first entry
    stated = ctx.trip.stated_consulate
    if stated is None:
        return _out(PASS, computed, computed, check)          # finding only
    return _out(PASS if stated == computed else FAIL, stated, computed, check)


def recency(check: Check, ctx: Context) -> CheckOutcome:
    d = _date(ctx.resolve(check.field_path))
    n = int(check.params["within_days"])
    expected = {"within_days": n, "as_of": ctx.today.isoformat()}
    if d is None:
        return _out(INDETERMINATE, ctx.resolve(check.field_path), expected, check)
    ok = ctx.today - timedelta(days=n) <= d <= ctx.today
    return _out(PASS if ok else FAIL, d.isoformat(), expected, check)


def format_check(check: Check, ctx: Context) -> CheckOutcome:
    v = ctx.resolve(check.field_path)
    p = check.params
    if v is None:
        return _out(INDETERMINATE, v, p, check)
    if "regex" in p:
        ok = re.fullmatch(p["regex"], str(v)) is not None
        return _out(PASS if ok else FAIL, v, {"regex": p["regex"]}, check)
    if "dimensions" in p:
        want = p["dimensions"]
        tol = want.get("tolerance_mm", 0)
        if not isinstance(v, dict) or v.get("width_mm") is None or v.get("height_mm") is None:
            return _out(INDETERMINATE, v, want, check)
        ok = abs(v["width_mm"] - want["width_mm"]) <= tol and abs(v["height_mm"] - want["height_mm"]) <= tol
        return _out(PASS if ok else FAIL, v, want, check)
    return _out(INDETERMINATE, v, p, check)


PRIMITIVES = {
    "threshold": threshold,
    "date_coverage": date_coverage,
    "set_membership": set_membership,
    "presence": presence,
    "cross_document_match": cross_document_match,
    "derived_routing": derived_routing,
    "recency": recency,
    "format": format_check,
}
