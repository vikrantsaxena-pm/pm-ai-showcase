"""Deterministic check engine (BUILD_SPEC §8). No LLM, no DB access here."""
