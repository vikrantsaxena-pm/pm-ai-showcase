"""Domain models for the check engine (BUILD_SPEC §5, §8).

Plain dataclasses mirroring the rows the engine reads/writes. No LLM, no DB —
the repository layer supplies these from fixture rows (in-memory) now and from
Supabase later.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import date, datetime
from typing import Any

# Verdicts. Primitives return the first three; the orchestrator sets BLOCKED
# when a check's prerequisite document has not been uploaded.
PASS = "pass"
FAIL = "fail"
INDETERMINATE = "indeterminate"
BLOCKED = "blocked"


@dataclass
class Ruleset:
    id: str
    jurisdiction: str
    visa_type: str
    purpose: str
    version: int
    effective_from: date
    status: str                       # §7 state machine; only 'in_force' resolves
    parent_ruleset_id: str | None = None   # inheritance (schengen_base)
    effective_to: date | None = None


@dataclass
class Check:
    id: str
    ruleset_id: str
    check_key: str
    check_type: str                   # one of the 8 primitives (§8)
    field_path: str
    citation: dict                    # {snapshot_id, clause, page, ratified}
    severity: str
    fix_lead_time_days: int
    operator: str | None = None
    value: Any = None
    params: dict = field(default_factory=dict)
    document_type: str | None = None
    depends_on_documents: list[str] = field(default_factory=list)


@dataclass
class DocumentRequirement:
    id: str
    ruleset_id: str
    document_type: str
    display_name: str
    max_fix_lead_time_days: int       # §6 Gap 2 ordering key (desc)
    folder_name: str
    required: bool = True


@dataclass
class Session:
    id: str
    jurisdiction: str
    purpose: str
    planned_visit_date: date          # THE forward-looking resolution key
    consent_given_at: datetime
    expires_at: datetime
    itinerary: dict | None = None     # {entries: [{country, nights}], start_date, end_date, stated_consulate}
    derived_consulate: str | None = None
    ruleset_id: str | None = None
    status: str = "active"


@dataclass
class SessionDocument:
    id: str
    session_id: str
    document_type: str
    extracted: dict                   # the fields the checks read (extractor output)
    extraction_confidence: float | None = None
    superseded_by: str | None = None
    status: str = "uploaded"          # uploaded | skipped | superseded


@dataclass
class CheckOutcome:
    """What a primitive returns."""
    verdict: str
    extracted_value: Any
    expected_value: Any
    citation: dict


@dataclass
class CheckResult:
    session_id: str
    check_id: str
    check_key: str                    # denormalized for readability/tests
    verdict: str
    extracted_value: Any = None
    expected_value: Any = None
    citation: dict | None = None
    document_id: str | None = None
    narrative: str | None = None      # filled by the LLM in Phase 2, not here
    stale: bool = False
    computed_at: datetime | None = None
    id: str | None = None


@dataclass
class TripFacts:
    start_date: date | None = None
    end_date: date | None = None
    days: int | None = None
    entry_country: str | None = None
    stated_consulate: str | None = None
    itinerary: list[dict] = field(default_factory=list)   # [{country, nights}] in travel order


@dataclass
class Context:
    """Everything a primitive may read. `resolve` walks dotted field paths.

    Namespaces: a document_type ('insurance.coverage_amount') or 'trip'
    ('trip.end_date'). Missing anything returns None (never raises) — a missing
    value becomes `indeterminate`, never a pass (invariant 9).
    """
    documents: dict[str, dict]        # document_type -> extracted dict
    trip: TripFacts
    today: date

    def resolve(self, path: str) -> Any:
        parts = path.split(".")
        head, rest = parts[0], parts[1:]
        if head == "trip":
            obj: Any = {
                "start_date": self.trip.start_date,
                "end_date": self.trip.end_date,
                "days": self.trip.days,
                "entry_country": self.trip.entry_country,
                "stated_consulate": self.trip.stated_consulate,
                "itinerary": self.trip.itinerary,
            }
        else:
            obj = self.documents.get(head)
        for key in rest:
            if isinstance(obj, dict):
                obj = obj.get(key)
            else:
                return None
        return obj
