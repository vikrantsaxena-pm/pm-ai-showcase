"""FastAPI application entry point (Phase 0 skeleton).

The API is the product; the two Streamlit UIs (later phases) are clients of it.
No business endpoints, LLM calls, or check logic exist yet — only liveness and a
readiness view that reports configuration presence (never secret values).
"""

from __future__ import annotations

from fastapi import FastAPI

from . import __version__
from .config import get_settings
from .providers import llm_provider, llm_model

app = FastAPI(
    title="Visa Document Validator API",
    version=__version__,
    summary="Rules-driven visa document validation. The API is the product.",
)


@app.get("/")
def root() -> dict:
    return {"service": "visa-document-validator", "version": __version__, "phase": 0}


@app.get("/health")
def health() -> dict:
    """Liveness only. Proves the app booted — not that any flow works."""
    return {"status": "ok"}


@app.get("/readiness")
def readiness() -> dict:
    """Config presence, no secret values. Nothing here connects out."""
    settings = get_settings()
    return {
        "status": "ok",
        "supabase_configured": settings.supabase_configured,
        "llm_provider": llm_provider(),
        "llm_model": llm_model(),
    }
