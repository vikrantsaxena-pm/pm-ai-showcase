"""Supabase client factory.

Lazily builds a client from env. Constructing the client does not open a
connection — no query is made until a later phase uses it. Nothing here runs in
Phase 0; it's the seam the API layer will use.
"""

from __future__ import annotations

from functools import lru_cache

from .config import get_settings


@lru_cache
def get_supabase():
    """Return a cached Supabase client (service-role key).

    Raises a clear error if Supabase isn't configured yet.
    """
    from supabase import create_client

    settings = get_settings()
    if not settings.supabase_configured:
        raise RuntimeError(
            "Supabase is not configured. Set SUPABASE_URL and SUPABASE_SERVICE_KEY "
            "in your .env (create the project in ap-south-1). See .env.example."
        )
    return create_client(settings.supabase_url, settings.supabase_service_key)
