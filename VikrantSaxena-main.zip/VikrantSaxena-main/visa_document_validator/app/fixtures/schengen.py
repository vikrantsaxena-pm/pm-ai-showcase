"""Fixture rule rows for the check engine (offline).

⚠️ THESE ARE SYNTHETIC TEST FIXTURES, NOT the ratified §9 seed.
The real seed requires human-captured primary-source snapshots and real
citations (deferred — see Phase 0). Here, citations are placeholders marked
`ratified: false`, and every numeric/list value is chosen to exercise the
engine, not asserted as current law. The point they DO prove: the engine is
data-driven — a jurisdiction is added by inserting rows, with zero code changes.

Structure: `schengen_base` (parent) + an `Italy` delta that overrides one check
(`sufficient_means` daily requirement), demonstrating inheritance/override.
"""

from __future__ import annotations

from datetime import date

from ..engine.models import Check, DocumentRequirement, Ruleset
from ..engine.repository import Repository

# Fixture citation — deliberately NOT a real clause reference (invariant 4).
FIXTURE_CITATION = {
    "snapshot_id": "fixture",
    "clause": "FIXTURE — synthetic test data, not a ratified citation",
    "page": None,
    "ratified": False,
}

# The 29 Schengen states (fixture list — verify against the primary source before
# any production ratification). Codes, not a legal assertion.
SCHENGEN_29 = [
    "AT", "BE", "BG", "HR", "CZ", "DK", "EE", "FI", "FR", "DE",
    "GR", "HU", "IS", "IT", "LV", "LI", "LT", "LU", "MT", "NL",
    "NO", "PL", "PT", "RO", "SK", "SI", "ES", "SE", "CH",
]

BASE_ID = "rs_base"
ITALY_ID = "rs_it"


def _base_checks() -> list[Check]:
    c = lambda **kw: Check(  # noqa: E731 - terse local row builder
        citation=FIXTURE_CITATION, ruleset_id=BASE_ID, **kw
    )
    return [
        c(id="c_ins_cov", check_key="insurance_min_coverage", check_type="threshold",
          field_path="insurance.coverage_amount", operator=">=",
          value={"amount": 30000, "currency": "EUR"},
          severity="critical", fix_lead_time_days=14, document_type="insurance"),
        c(id="c_ins_terr", check_key="insurance_territory", check_type="set_membership",
          field_path="insurance.territory", value=SCHENGEN_29, params={"mode": "superset"},
          severity="critical", fix_lead_time_days=14, document_type="insurance"),
        c(id="c_ins_rep", check_key="insurance_repatriation", check_type="presence",
          field_path="insurance.repatriation",
          severity="critical", fix_lead_time_days=14, document_type="insurance"),
        c(id="c_ins_dates", check_key="insurance_date_coverage", check_type="date_coverage",
          field_path="insurance",
          params={"a_start": "insurance.coverage_start", "a_end": "insurance.coverage_end",
                  "b_start": "flight.departure_date", "b_end": "flight.return_date",
                  "tolerance_days": 0},
          severity="critical", fix_lead_time_days=14, document_type="insurance",
          depends_on_documents=["insurance", "flight"]),
        c(id="c_passport", check_key="passport_validity", check_type="threshold",
          field_path="passport.expiry_date", operator=">=",
          params={"rhs": {"date_offset": {"of": {"context": "flight.return_date"}, "months": 3}}},
          severity="critical", fix_lead_time_days=30, document_type="passport",
          depends_on_documents=["passport", "flight"]),
        c(id="c_route", check_key="consulate_routing", check_type="derived_routing",
          field_path="trip.itinerary",
          severity="major", fix_lead_time_days=1, document_type=None),
        c(id="c_means", check_key="sufficient_means", check_type="threshold",
          field_path="bank.balance", operator=">=",
          params={"rhs": {"product": [{"context": "trip.days"},
                                       {"const": {"amount": 70, "currency": "EUR"}}]}},
          severity="critical", fix_lead_time_days=56, document_type="bank"),
        c(id="c_name", check_key="cross_doc_name_match", check_type="cross_document_match",
          field_path="passport.full_name",
          params={"left": "passport.full_name", "right": "insurance.holder_name",
                  "match": "name", "min_ratio": 0.85},
          severity="major", fix_lead_time_days=14, document_type="passport",
          depends_on_documents=["passport", "insurance"]),
        c(id="c_date", check_key="cross_doc_date_match", check_type="cross_document_match",
          field_path="flight.return_date",
          params={"left": "flight.return_date", "right": "insurance.coverage_end",
                  "match": "exact"},
          severity="major", fix_lead_time_days=14, document_type="flight",
          depends_on_documents=["flight", "insurance"]),
        # Beyond §9 minimum, to exercise the remaining two §8 primitives:
        c(id="c_recency", check_key="bank_statement_recency", check_type="recency",
          field_path="bank.statement_date", params={"within_days": 30},
          severity="major", fix_lead_time_days=2, document_type="bank"),
        c(id="c_photo", check_key="photo_format", check_type="format",
          field_path="photo.dimensions",
          params={"dimensions": {"width_mm": 35, "height_mm": 45, "tolerance_mm": 0}},
          severity="minor", fix_lead_time_days=1, document_type="photo"),
    ]


def _base_requirements() -> list[DocumentRequirement]:
    r = lambda **kw: DocumentRequirement(ruleset_id=BASE_ID, **kw)  # noqa: E731
    return [
        r(id="dr_bank", document_type="bank", display_name="Bank statement",
          max_fix_lead_time_days=56, folder_name="01_financial"),
        r(id="dr_passport", document_type="passport", display_name="Passport",
          max_fix_lead_time_days=30, folder_name="02_identity"),
        r(id="dr_insurance", document_type="insurance", display_name="Travel insurance",
          max_fix_lead_time_days=14, folder_name="03_insurance"),
        r(id="dr_flight", document_type="flight", display_name="Flight itinerary",
          max_fix_lead_time_days=7, folder_name="04_travel"),
        r(id="dr_photo", document_type="photo", display_name="Passport photo",
          max_fix_lead_time_days=1, folder_name="05_photo"),
    ]


def seed(repo: Repository) -> None:
    """Load the fixture rulesets, checks, and requirements into a repository."""
    repo.add_ruleset(Ruleset(
        id=BASE_ID, jurisdiction="schengen", visa_type="schengen_c", purpose="tourism",
        version=1, effective_from=date(2020, 2, 2), status="in_force",
    ))
    for check in _base_checks():
        repo.add_check(check)
    for req in _base_requirements():
        repo.add_document_requirement(req)

    # Italy consulate delta — inherits base, overrides ONE check (daily means).
    repo.add_ruleset(Ruleset(
        id=ITALY_ID, jurisdiction="schengen/IT", visa_type="schengen_c", purpose="tourism",
        version=1, effective_from=date(2020, 2, 2), status="in_force",
        parent_ruleset_id=BASE_ID,
    ))
    repo.add_check(Check(
        id="c_means_it", ruleset_id=ITALY_ID, check_key="sufficient_means",
        check_type="threshold", field_path="bank.balance", operator=">=",
        params={"rhs": {"product": [{"context": "trip.days"},
                                    {"const": {"amount": 50, "currency": "EUR"}}]}},
        citation=FIXTURE_CITATION, severity="critical", fix_lead_time_days=56,
        document_type="bank",
    ))
