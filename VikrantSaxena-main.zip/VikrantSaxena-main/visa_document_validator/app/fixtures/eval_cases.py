"""The eval set — the quality bar (BUILD_SPEC §10).

WRITTEN BEFORE THE PRIMITIVES. Each case is a set of extracted document values
(what the LLM extractor would produce) plus HAND-VERIFIED expected verdicts,
derived from the fixture rules — not from whatever the code happens to do.

Target: 0% false-pass (no case where expected != 'pass' but the engine says
'pass'). A false "you're fine" costs the user their trip.

Resolution jurisdiction is 'schengen/IT' (Italy delta: sufficient_means daily
requirement = €50, overriding base €70).
"""

from __future__ import annotations

import copy
from datetime import date

from .schengen import SCHENGEN_29

_REMOVE = object()   # sentinel: delete a field to simulate an extraction miss

# ── Base compliant applicant (every check passes) ──────────────────────────
BASE_DOCS: dict[str, dict] = {
    "insurance": {
        "coverage_amount": {"amount": 30000, "currency": "EUR"},
        "territory": list(SCHENGEN_29),
        "repatriation": True,
        "coverage_start": "2026-09-01",
        "coverage_end": "2026-09-10",
        "holder_name": "ROHAN KUMAR",
    },
    "flight": {"departure_date": "2026-09-01", "return_date": "2026-09-10"},
    "passport": {"full_name": "ROHAN KUMAR", "expiry_date": "2027-01-01"},
    "bank": {"balance": {"amount": 500, "currency": "EUR"}, "statement_date": "2026-07-20"},
    "photo": {"dimensions": {"width_mm": 35, "height_mm": 45}},
}

BASE_TRIP = {
    "entries": [{"country": "IT", "nights": 6}, {"country": "FR", "nights": 3}],
    "start_date": "2026-09-01",
    "end_date": "2026-09-10",
    "stated_consulate": "IT",
}

BASE_TODAY = date(2026, 8, 1)

# days = 9 nights; Italy daily €50 → means threshold = €450.
BASE_EXPECTED = {
    "insurance_min_coverage": "pass",
    "insurance_territory": "pass",
    "insurance_repatriation": "pass",
    "insurance_date_coverage": "pass",
    "passport_validity": "pass",
    "consulate_routing": "pass",
    "sufficient_means": "pass",
    "cross_doc_name_match": "pass",
    "cross_doc_date_match": "pass",
    "bank_statement_recency": "pass",
    "photo_format": "pass",
}


def _docs(**overrides) -> dict[str, dict]:
    d = copy.deepcopy(BASE_DOCS)
    for dtype, patch in overrides.items():
        if patch is None:
            d.pop(dtype, None)                      # drop the whole document
            continue
        for key, val in patch.items():
            if val is _REMOVE:
                d[dtype].pop(key, None)
            else:
                d[dtype][key] = val
    return d


def _trip(**overrides) -> dict:
    t = copy.deepcopy(BASE_TRIP)
    t.update(overrides)
    return t


def _exp(**changes) -> dict:
    return {**BASE_EXPECTED, **changes}


class EvalCase:
    def __init__(self, name, docs, expected, trip=None, today=None, why=""):
        self.name = name
        self.docs = docs
        self.expected = expected
        self.trip = trip or copy.deepcopy(BASE_TRIP)
        self.today = today or BASE_TODAY
        self.why = why


# ── The eval set ───────────────────────────────────────────────────────────
CASES: list[EvalCase] = [
    EvalCase("good", _docs(), _exp(), why="fully compliant → all pass"),

    # threshold boundaries — insurance minimum coverage (€30,000)
    EvalCase("ins_29999", _docs(insurance={"coverage_amount": {"amount": 29999, "currency": "EUR"}}),
             _exp(insurance_min_coverage="fail"), why="€29,999 < €30,000 → fail"),
    EvalCase("ins_30000", _docs(insurance={"coverage_amount": {"amount": 30000, "currency": "EUR"}}),
             _exp(), why="€30,000 == threshold → pass (>=)"),
    EvalCase("ins_30001", _docs(insurance={"coverage_amount": {"amount": 30001, "currency": "EUR"}}),
             _exp(), why="€30,001 > threshold → pass"),
    EvalCase("ins_amount_missing", _docs(insurance={"coverage_amount": _REMOVE}),
             _exp(insurance_min_coverage="indeterminate"),
             why="extraction miss → indeterminate, NEVER pass (invariant 9)"),

    # set_membership — territorial coverage must include all 29 states
    EvalCase("territory_missing_state",
             _docs(insurance={"territory": [c for c in SCHENGEN_29 if c != "IT"]}),
             _exp(insurance_territory="fail"), why="missing IT from covered set → fail"),

    # presence — repatriation
    EvalCase("repatriation_false", _docs(insurance={"repatriation": False}),
             _exp(insurance_repatriation="fail"), why="explicitly not covered → fail"),
    EvalCase("repatriation_missing", _docs(insurance={"repatriation": _REMOVE}),
             _exp(insurance_repatriation="indeterminate"),
             why="field not extracted → indeterminate, not pass"),

    # date_coverage — 0-day vs 1-day gap (gap on the start side to isolate)
    EvalCase("coverage_0day_gap", _docs(insurance={"coverage_start": "2026-09-01"}),
             _exp(), why="insurance starts exactly on trip start → covers → pass"),
    EvalCase("coverage_1day_gap", _docs(insurance={"coverage_start": "2026-09-02"}),
             _exp(insurance_date_coverage="fail"),
             why="starts 1 day late → 1-day gap → fail (tolerance 0)"),

    # threshold on dates — passport ≥ 3 months beyond return (return 2026-09-10 → 2026-12-10)
    EvalCase("passport_2mo", _docs(passport={"expiry_date": "2026-11-10"}),
             _exp(passport_validity="fail"), why="expires 2 months after return < 3-month bound → fail"),

    # threshold — sufficient means (days 9 × €50 = €450)
    EvalCase("means_low", _docs(bank={"balance": {"amount": 400, "currency": "EUR"}}),
             _exp(sufficient_means="fail"), why="€400 < €450 → fail"),
    EvalCase("means_exact_450", _docs(bank={"balance": {"amount": 450, "currency": "EUR"}}),
             _exp(), why="€450 == threshold → pass"),
    EvalCase("means_currency_mismatch", _docs(bank={"balance": {"amount": 600, "currency": "USD"}}),
             _exp(sufficient_means="indeterminate"),
             why="USD vs EUR, no rate → cannot compare → indeterminate, not pass"),

    # cross_document_match — names (fuzzy) and dates (exact)
    EvalCase("name_mismatch_person", _docs(insurance={"holder_name": "PRIYA SHARMA"}),
             _exp(cross_doc_name_match="fail"), why="different person → fail"),
    EvalCase("name_typo_surname", _docs(insurance={"holder_name": "ROHAN KUMAAR"}),
             _exp(), why="one-char surname typo → within ratio → pass (near-match)"),
    EvalCase("name_middle_initial", _docs(insurance={"holder_name": "ROHAN A KUMAR"}),
             _exp(), why="added middle initial → token subset → pass"),
    EvalCase("name_first_diff_person", _docs(insurance={"holder_name": "MOHAN KUMAR"}),
             _exp(cross_doc_name_match="fail"),
             why="Rohan vs Mohan — 1-char first-name diff but a DIFFERENT person → must NOT false-pass"),
    EvalCase("date_mismatch", _docs(insurance={"coverage_end": "2026-09-11"}),
             _exp(cross_doc_date_match="fail"),
             why="insurance end 09-11 ≠ flight return 09-10 → fail (coverage still holds)"),

    # derived_routing — most nights, tie → first entry
    EvalCase("wrong_consulate", _docs(), _exp(consulate_routing="fail"),
             trip=_trip(stated_consulate="FR"),
             why="most nights IT but applying to FR → fail"),
    EvalCase("consulate_tie", _docs(), _exp(),
             trip=_trip(entries=[{"country": "IT", "nights": 5}, {"country": "FR", "nights": 5}]),
             why="5/5 tie → first entry IT → matches stated IT → pass"),

    # recency — bank statement within 30 days of today (2026-08-01)
    EvalCase("recency_boundary_30", _docs(bank={"statement_date": "2026-07-02"}),
             _exp(), why="exactly 30 days old → within window → pass"),
    EvalCase("recency_31", _docs(bank={"statement_date": "2026-07-01"}),
             _exp(bank_statement_recency="fail"), why="31 days old → outside window → fail"),
    EvalCase("recency_future", _docs(bank={"statement_date": "2026-08-05"}),
             _exp(bank_statement_recency="fail"), why="future-dated → fail"),

    # format — photo dimensions
    EvalCase("photo_wrong_dims", _docs(photo={"dimensions": {"width_mm": 30, "height_mm": 40}}),
             _exp(photo_format="fail"), why="30×40 ≠ 35×45 → fail"),
    EvalCase("photo_missing", _docs(photo={"dimensions": _REMOVE}),
             _exp(photo_format="indeterminate"), why="no dimensions extracted → indeterminate"),

    # blocked — a prerequisite document not uploaded
    EvalCase("flight_missing_blocked", _docs(flight=None),
             _exp(passport_validity="blocked", insurance_date_coverage="blocked",
                  cross_doc_date_match="blocked"),
             why="no flight doc → its dependent checks are blocked, not failed/passed"),
]
