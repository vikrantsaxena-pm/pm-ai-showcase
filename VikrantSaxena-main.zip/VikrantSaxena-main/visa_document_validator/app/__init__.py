"""Visa Document Validator — FastAPI product (see BUILD_SPEC.md)."""

__version__ = "0.0.0"  # Phase 0 scaffold
