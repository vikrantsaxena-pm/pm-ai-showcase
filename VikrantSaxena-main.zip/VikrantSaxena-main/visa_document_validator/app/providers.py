"""Provider-agnostic LLM access (BUILD_SPEC §3, §11).

One module, three providers, selected by env. Per invariant §2.1 the LLM only
ever (a) extracts fields and (b) narrates from computed JSON — those flows are
built in later phases. This module provides the raw, provider-neutral call they
will use; it is NOT invoked anywhere in Phase 0 (no LLM calls yet).

  LLM_PROVIDER   claude | openai | gemini   (default: claude)
  LLM_MODEL      overrides the per-provider default
  ANTHROPIC_API_KEY / OPENAI_API_KEY / GEMINI_API_KEY (or GOOGLE_API_KEY)

SDKs are imported lazily so importing this module never requires all three.
"""

from __future__ import annotations

import os

LLM_DEFAULTS = {
    "claude": "claude-opus-4-8",
    "openai": "gpt-4o",
    "gemini": "gemini-2.5-flash",
}


class ProviderError(RuntimeError):
    """Configuration/API error with a user-friendly message."""


def llm_provider() -> str:
    return os.getenv("LLM_PROVIDER", "claude").strip().lower()


def llm_model() -> str:
    return os.getenv("LLM_MODEL", "").strip() or LLM_DEFAULTS.get(llm_provider(), "")


def _require_key(*names: str) -> str:
    for name in names:
        val = os.getenv(name)
        if val:
            return val
    raise ProviderError(
        f"Missing API key. Set one of: {', '.join(names)} in your environment (.env)."
    )


def generate(system: str, user: str, max_tokens: int = 2000) -> str:
    """Provider-neutral text generation. Not called in Phase 0."""
    provider = llm_provider()
    model = llm_model()
    if provider in ("claude", "anthropic"):
        return _gen_claude(model, system, user, max_tokens)
    if provider == "openai":
        return _gen_openai(model, system, user)
    if provider in ("gemini", "google"):
        return _gen_gemini(model, system, user)
    raise ProviderError(
        f"Unknown LLM_PROVIDER '{provider}'. Use one of: claude, openai, gemini."
    )


def _gen_claude(model: str, system: str, user: str, max_tokens: int) -> str:
    import anthropic

    client = anthropic.Anthropic(api_key=_require_key("ANTHROPIC_API_KEY"))
    resp = client.messages.create(
        model=model,
        max_tokens=max_tokens,
        system=system,
        messages=[{"role": "user", "content": user}],
    )
    return "".join(b.text for b in resp.content if b.type == "text").strip()


def _gen_openai(model: str, system: str, user: str) -> str:
    from openai import OpenAI

    client = OpenAI(api_key=_require_key("OPENAI_API_KEY"))
    resp = client.chat.completions.create(
        model=model,
        messages=[
            {"role": "system", "content": system},
            {"role": "user", "content": user},
        ],
    )
    return (resp.choices[0].message.content or "").strip()


def _gen_gemini(model: str, system: str, user: str) -> str:
    from google import genai
    from google.genai import types

    client = genai.Client(api_key=_require_key("GEMINI_API_KEY", "GOOGLE_API_KEY"))
    resp = client.models.generate_content(
        model=model,
        contents=user,
        config=types.GenerateContentConfig(system_instruction=system),
    )
    return (resp.text or "").strip()
