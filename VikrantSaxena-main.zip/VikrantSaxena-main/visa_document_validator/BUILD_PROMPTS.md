# BUILD_PROMPTS.md — paste sheet for Claude Code

Paste one phase at a time. **Verify each before moving on.** Do not batch.

Every phase assumes `BUILD_SPEC.md` is at the repo root.

---

## Before you start — two decisions

**1. Where does this live?** This is a full product (FastAPI + Supabase + crawler + two UIs). It does **not** fit a "collection of runnable Streamlit demos" repo. Recommendation: **its own repo**. If you put it in the portfolio repo, give it its own subdirectory and its own `BUILD_SPEC.md`, and expect the conventions to clash.

**2. Supabase project.** Create it first (ap-south-1 for data residency). You'll need `SUPABASE_URL` and `SUPABASE_SERVICE_KEY` before Phase 0.

---

## Phase 0 — Scaffold + schema + seed

> Read `BUILD_SPEC.md` fully first — it is authoritative.
>
> Set up the project skeleton and database:
> 1. FastAPI app skeleton, `providers.py` for provider-agnostic LLM access (Claude/OpenAI/Gemini via env), pinned `requirements.txt`, `.env.example` with placeholders.
> 2. Supabase migration implementing the exact schema in §5. Every table, every column, every constraint.
> 3. A seed script that inserts the `schengen_base` ruleset + Italy consulate delta with the checks listed in §9.
>
> Critical for the seed: every check must carry a real citation pointing at a captured source snapshot. I will provide the EU Visa Code PDF and the Italy consulate page capture. **Do not invent clause numbers or page references.** If you cannot locate a clause in the provided snapshot, leave that check unratified and tell me which ones.
>
> Do not build any UI or LLM calls in this phase.
>
> Verify: migration applies cleanly, seed inserts, and a query for `jurisdiction='schengen/IT', purpose='tourism', planned_visit_date='2026-09-01'` returns the right ruleset with its checks.

**You must supply:** the EU Visa Code PDF and an Italy consulate requirements capture. Claude Code cannot fetch these (CAPTCHA/anti-bot). Capture them yourself, save the official URL, and hand over the files.

---

## Phase 1 — Check engine + eval set (no LLM, no UI)

> Read `BUILD_SPEC.md`. Build the check engine.
>
> 1. Implement all 8 check primitives from §8 as pure Python. Each takes an extracted value + a rule row, returns `pass | fail | indeterminate` plus extracted value, expected value, and the citation from the rule row.
> 2. Build the eval set **first**: fixtures of known-good and known-bad extracted values with hand-verified expected verdicts. Include boundary cases — €29,999 / €30,000 / €30,001, 0-day gap, 1-day gap, name near-matches.
> 3. Implement the orchestrator: given a session and a set of extracted document values, resolve the ruleset by `planned_visit_date`, run every applicable check, return results.
> 4. Implement cascade invalidation (§6 Gap 3): given a re-uploaded document type, mark dependent `check_results` stale and re-run exactly those.
>
> Hard constraints: no LLM anywhere in this phase. No hard-coded thresholds — every value comes from the DB. Adding a jurisdiction must require zero code changes.
>
> Verify: all boundary tests pass, 0% false-pass on the eval set, determinism test passes (same inputs → identical verdict twice), cascade test passes.

**This is the foundation. Do not move on until the eval set is green.**

---

## Phase 2 — Extraction + validation API + purge job

> Read `BUILD_SPEC.md`. Add the LLM extraction layer and expose the API.
>
> 1. Extraction: given an uploaded document and a `document_type`, the LLM extracts the structured fields the checks need (per `field_path`). Returns extracted JSON + a confidence signal. **Low confidence or missing field → `indeterminate`, never `pass`** (invariant 9).
> 2. Narration: given computed check results, the LLM writes the explanation. It reads from computed JSON only — it must never introduce a number that isn't in the results.
> 3. FastAPI endpoints: create session, list document requirements (ordered by `max_fix_lead_time_days` DESC — §6 Gap 2), upload document, get results, re-upload, skip document, generate ZIP docket.
> 4. Document storage: encrypted at rest, `sessions.expires_at` TTL (default 30 days). **Write the purge job now and prove it runs** — not later.
> 5. Consent capture at session creation (DPDPA).
>
> Verify: end-to-end on a real insurance PDF fixture; extraction populates the fields the checks need; a €25,000 policy fails `insurance_min_coverage` with a real citation; the narration contains no number absent from the computed results; the purge job actually deletes an expired session's documents.

---

## Phase 3 — Applicant UI (chat + panel)

> Read `BUILD_SPEC.md`. Build the applicant Streamlit app as a client of the API.
>
> Flow per §6:
> 1. Ask destination + **purpose** + planned visit date + itinerary (purpose is required — §6 Gap 1).
> 2. Derive the consulate from the itinerary and surface it as the first finding, with citation, **before any upload**.
> 3. Request documents in lead-time order. Each upload → verify → comment → ask for the next in the same reply.
> 4. Under every verdict: a **[Re-upload]** button (triggers cascade re-validation) and an **[I don't have this yet]** button (marks skipped, keeps session alive — §6 Gap 4).
> 5. **Persistent checklist panel in the sidebar** showing every requirement and its state (§6 Gap 5). Chat alone cannot answer "what's left?".
> 6. Final summary grouped by fix lead time: "Fix today (1–2d)" / "Start now (4–8w)" / "Cannot assess".
> 7. ZIP docket download, foldered per `document_requirements.folder_name`.
>
> Every response must show the freshness stamp reading from `last_success_at` (invariant 5), and must never state or imply approval likelihood (invariant 6).
>
> Verify: click through the full flow with real fixtures. Re-upload a document and confirm dependent checks re-run. Confirm the ZIP folders are correct.

---

## Phase 4 — Review console + queue

> Read `BUILD_SPEC.md`. Build the internal review console (Streamlit).
>
> 1. Queue sorted by **risk**, not recency: 🔴 at-risk (<7d to effective, unratified) → 🟠 verify (effective date passed, unverified) → 🟡 limbo (pending_implementation >30d) → 🟢 scheduled → ⚫ stale source.
> 2. **Shared queue with claim lock**: any employee can claim an item; claim records `claimed_by`/`claimed_at`; claim auto-expires after 48h inactivity and returns to the pool.
> 3. Item detail: signal summary, proposed diff, source. Actions: **Accept** (→ ratified, effective-dated) / **Reject** (→ sets `suppression_hash`, does not re-queue until source hash changes again) / **Need investigation** (requires a deadline).
> 4. **Enforce the deadline cap (§7 Gap 6)**: `investigation_deadline` must be `< target_effective_from - 3 days`. Reject the input otherwise. This is a hard validation, not a warning.
> 5. **Provenance is a required field**: before ratifying, the reviewer must supply the official URL + upload the page snapshot. Store as a `source_snapshots` row; the citation points at it. Cannot ratify without it (invariant 7).
> 6. Implement the ruleset state machine from §7 exactly, including `announced_pending` and `pending_implementation` — both of which **never fire**.
> 7. T+1 verification task auto-created the day after `effective_from`; unverified at T+7 → roll back + flag.
>
> Verify: try to set a deadline past the effective date — must be rejected. Try to ratify without provenance — must be blocked. Confirm an `announced_pending` ruleset does not resolve at request time even when the planned date is after its effective_from.

---

## Phase 5 — Crawler + change detection + cohort notification

> Read `BUILD_SPEC.md`. Build the change-detection backend.
>
> 1. Scheduler polls `sources` by tier (tier 2 daily, tier 1 weekly, tier 0 monthly). ~15 daily URLs, not 150.
> 2. Pipeline: fetch → extract content region via `content_selector` → normalize → hash → compare to `last_hash`. **If unchanged (≈95% of runs): update `last_success_at` and stop. No LLM call.**
> 3. On change: semantic diff → LLM triage answering only "which of our registered checks does this affect?" → create a `change_queue` item. **The crawler never drafts the final rule from a secondary source** (invariant 7) — it produces a signal for a human to investigate against the primary source.
> 4. Failure handling: increment `consecutive_failures`; past N, set `sources.status='degraded'` → user-facing staleness warning fires automatically.
> 5. Alert when extracted content length changes >50% — that's selector rot, not a content change.
> 6. **Cohort notification (the missing link between the two sides):** when a ruleset transitions to `in_force`, notify exactly the users where `jurisdiction` matches AND `planned_visit_date >= effective_from` AND `last_validated_at < effective_from`. Nobody else.
> 7. Auto-degrade: if a queue item passes `target_effective_from` unresolved, degrade that jurisdiction so users see the warning.
>
> Verify: simulate a source change and confirm it flows signal → queue → claim → ratify → scheduled → fires on the effective date. Simulate a dead source and confirm freshness shows "last verified N days ago" (from `last_success_at`) and degradation fires. Simulate an `in_force` transition and confirm only the affected cohort is selected.

---

## After each phase

```bash
git add .
git commit -m "feat(visa): phase N — <what>"
git push
```

---

## The three things Claude Code cannot do for you

1. **Capture the primary sources.** CAPTCHA and anti-bot will block it. You open the official page, save the PDF, record the URL. This is the manual bootstrap — one afternoon for Schengen.
2. **Verify the domain logic is right.** Is €30,000 actually the current minimum? Does that clause number exist on that page? Claude Code will produce plausible rules. Only you can confirm they're true.
3. **Answer the open questions** in the PRD — the preventability share, the business model, liability, DPDPA counsel. Architecture doesn't resolve any of them.
