# Visa Document Validator

A rules-driven visa document validator. **This is a full product, not a demo
app** — a FastAPI service (the product) backed by Supabase, kept current by a
crawler + human review loop, with two Streamlit apps as reference clients.

**`BUILD_SPEC.md` in this folder is authoritative** and supersedes the repo's
root `CLAUDE.md` (which describes single-file Streamlit demos). `BUILD_PROMPTS.md`
is the phased build plan.

## Status
**Phase 0 (scaffold + schema)** — FastAPI skeleton (`app/`, liveness/readiness
only), `app/providers.py` (provider-agnostic LLM, not invoked), `app/db.py`
(lazy Supabase client), and `supabase/migrations/…_init_schema.sql` — the exact
§5 schema, **written, not applied** (no Supabase project yet).

**Phase 1 (check engine + eval set)** — done, fully offline, no LLM:
- `app/engine/` — the 8 §8 check primitives (pure Python), a `Repository`
  interface + `InMemoryRepository`, and the orchestrator (ruleset resolution by
  `planned_visit_date`, run checks, cascade invalidation per §6 Gap 3).
- `app/fixtures/` — **synthetic** rule rows (`schengen_base` + Italy delta) and
  the **eval set** (27 hand-verified cases). ⚠️ Fixtures carry placeholder
  citations marked `ratified: false` — they are NOT the ratified §9 seed (which
  needs the real primary-source captures). They exist to prove the engine is
  data-driven and correct.
- Invariants held: no LLM; no hard-coded values (every threshold/list/date rule
  is a rule row); adding a jurisdiction is adding rows (the Italy delta overrides
  one check with **zero code changes**).

Deferred: the ratified §9 seed (pending captures), and Phases 2–5
(extraction/narration API, UIs, review console, crawler).

## Run the check-engine tests (offline, no LLM, no DB)
```bash
cd visa_document_validator
python tests/test_primitives_boundaries.py   # €29,999/€30,000/€30,001, 0/1-day gap, name near-matches
python tests/test_eval_set.py                # 27 cases, 0% false-pass (the quality bar)
python tests/test_orchestrator.py            # resolution, inheritance override, blocked, no-ruleset
python tests/test_cascade.py                 # re-upload re-runs EXACTLY the dependent checks
python tests/test_determinism.py             # same inputs → identical verdicts
```
Pure stdlib — no venv required for these.

## Run (local skeleton)
```bash
cd visa_document_validator
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env            # optional in Phase 0; app boots without config
uvicorn app.main:app --reload
```
Then: `curl localhost:8000/health` → `{"status":"ok"}`, and `/readiness` reports
config presence (no secrets).

## Apply the migration (later, once the Supabase project exists)
Not applied yet. When ready, with the Supabase CLI linked to your project:
```bash
supabase db push          # applies supabase/migrations/*.sql
```

## Invariants (from BUILD_SPEC §2 — do not violate)
- The LLM never decides anything: it only extracts fields and narrates from
  computed JSON. Every pass/fail is Python comparing an extracted value to a
  ratified rule.
- Rules are data, not code. Adding a jurisdiction = inserting rows.
- Freshness reads `last_success_at`, never `last_fetched_at`.
- Never certify approval; extraction failure ≠ pass.
