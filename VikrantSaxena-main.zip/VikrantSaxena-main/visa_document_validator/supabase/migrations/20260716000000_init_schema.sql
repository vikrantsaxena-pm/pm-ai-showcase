-- Visa Document Validator — initial schema
-- Implements BUILD_SPEC.md §5 exactly: every table, column, and constraint.
-- Tables are ordered so foreign-key references resolve at create time.
--
-- NOTE: RLS policies and Storage buckets (BUILD_SPEC §3) are intentionally NOT
-- in this migration — §5 defines no policies, and this file mirrors §5 exactly.
-- They land in a later phase.

-- gen_random_uuid() is in core Postgres 13+ (Supabase runs 15+); pgcrypto is a
-- no-op safety net for older targets and is idempotent.
create extension if not exists pgcrypto;

-- ── SOURCES ────────────────────────────────────────────────
create table sources (
  id uuid primary key default gen_random_uuid(),
  jurisdiction text not null,              -- 'schengen/IT'
  tier int not null,                       -- 0 | 1 | 2
  role text not null check (role in ('primary','secondary')),
  url text not null,
  content_selector text,                   -- strips nav/banners
  fetch_frequency interval not null,       -- tier2: 1d, tier1: 7d, tier0: 30d
  last_fetched_at timestamptz,
  last_success_at timestamptz,             -- FRESHNESS READS THIS
  last_hash text,
  consecutive_failures int not null default 0,
  status text not null default 'active'    -- active | degraded | dead
);

-- ── IMMUTABLE EVIDENCE ─────────────────────────────────────
create table source_snapshots (
  id uuid primary key default gen_random_uuid(),
  source_id uuid references sources(id),
  official_url text not null,              -- REQUIRED, even for manual capture
  storage_path text not null,              -- the captured PDF/HTML
  content_hash text not null,
  captured_at timestamptz not null default now(),
  captured_by uuid                         -- null = crawler, else employee
);

-- ── RULES ──────────────────────────────────────────────────
create table rulesets (
  id uuid primary key default gen_random_uuid(),
  jurisdiction text not null,
  visa_type text not null,                 -- 'schengen_c'
  purpose text not null,                   -- tourism | business | family_visit
  version int not null,
  parent_ruleset_id uuid references rulesets(id),   -- inheritance: schengen_base
  announced_at date,
  effective_from date not null,
  effective_to date,
  status text not null,                    -- see §7 state machine
  source_snapshot_id uuid references source_snapshots(id),
  implementation_verified_at timestamptz,
  last_verified_at timestamptz,
  ratified_by uuid,
  ratified_at timestamptz,
  created_at timestamptz not null default now()
);

create table checks (
  id uuid primary key default gen_random_uuid(),
  ruleset_id uuid references rulesets(id) on delete cascade,
  check_key text not null,                 -- 'insurance_min_coverage'
  check_type text not null,                -- one of the 8 primitives
  field_path text not null,                -- 'insurance.coverage_amount'
  operator text,
  value jsonb,
  params jsonb,
  citation jsonb not null,                 -- {snapshot_id, clause, page}
  severity text not null,
  fix_lead_time_days int not null,         -- DRIVES ordering + report sort
  document_type text,                      -- which doc satisfies this
  depends_on_documents text[]              -- for cross_document_match
);

create table document_requirements (
  id uuid primary key default gen_random_uuid(),
  ruleset_id uuid references rulesets(id) on delete cascade,
  document_type text not null,
  display_name text not null,
  required boolean not null default true,
  max_fix_lead_time_days int not null,     -- ORDERING KEY, desc
  folder_name text not null                -- for the ZIP docket
);

-- ── SESSIONS ───────────────────────────────────────────────
create table sessions (
  id uuid primary key default gen_random_uuid(),
  jurisdiction text not null,
  purpose text not null,                   -- §6 Gap 1
  planned_visit_date date not null,        -- THE forward-looking key
  itinerary jsonb,                         -- nights per country
  derived_consulate text,
  ruleset_id uuid references rulesets(id),
  consent_given_at timestamptz not null,   -- DPDPA
  expires_at timestamptz not null,         -- TTL purge
  status text not null default 'active',
  created_at timestamptz not null default now()
);

create table session_documents (
  id uuid primary key default gen_random_uuid(),
  session_id uuid references sessions(id) on delete cascade,
  document_type text not null,
  storage_path text,                       -- encrypted; purged at expires_at
  extracted jsonb,
  extraction_confidence float,
  superseded_by uuid references session_documents(id),  -- re-upload chain
  uploaded_at timestamptz not null default now(),
  status text not null default 'uploaded'  -- uploaded | skipped | superseded
);

create table check_results (
  id uuid primary key default gen_random_uuid(),
  session_id uuid references sessions(id) on delete cascade,
  check_id uuid references checks(id),
  document_id uuid references session_documents(id),
  verdict text not null,                   -- pass | fail | indeterminate | blocked
  extracted_value jsonb,
  expected_value jsonb,
  narrative text,
  stale boolean not null default false,    -- §6 Gap 3 cascade
  computed_at timestamptz not null default now()
);

-- ── CHANGE QUEUE ───────────────────────────────────────────
create table change_queue (
  id uuid primary key default gen_random_uuid(),
  jurisdiction text not null,
  detected_at timestamptz not null default now(),
  detected_by_source_id uuid references sources(id),
  signal_summary text,
  proposed_diff jsonb,
  target_effective_from date,              -- from the announcement
  claimed_by uuid,                         -- SHARED QUEUE + CLAIM LOCK
  claimed_at timestamptz,
  status text not null default 'detected', -- see §7
  investigation_deadline date,             -- CAPPED, see §7
  suppression_hash text,                   -- rejected → don't re-fire
  resolved_at timestamptz,
  resolved_by uuid
);
