"""Boundary tests on every primitive (§10), calling primitives directly."""

from __future__ import annotations

from datetime import date

import _harness  # noqa: F401 - sets sys.path

from app.engine.models import Check, Context, TripFacts
from app.engine.primitives import (
    cross_document_match,
    date_coverage,
    derived_routing,
    format_check,
    presence,
    recency,
    set_membership,
    threshold,
)

CIT = {"snapshot_id": "fixture", "ratified": False}


def ctx(documents=None, trip=None, today=date(2026, 8, 1)) -> Context:
    return Context(documents=documents or {}, trip=trip or TripFacts(), today=today)


def mk(check_type, **kw) -> Check:
    kw.setdefault("field_path", "x.y")
    return Check(id="c", ruleset_id="r", check_key="k", check_type=check_type,
                 citation=CIT, severity="major", fix_lead_time_days=1, **kw)


def test_threshold_money_boundary():
    chk = mk("threshold", field_path="insurance.coverage_amount", operator=">=",
             value={"amount": 30000, "currency": "EUR"})
    def v(amount):
        c = ctx(documents={"insurance": {"coverage_amount": {"amount": amount, "currency": "EUR"}}})
        return threshold(chk, c).verdict
    assert v(29999) == "fail"
    assert v(30000) == "pass"
    assert v(30001) == "pass"


def test_threshold_currency_mismatch_indeterminate():
    chk = mk("threshold", field_path="bank.balance", operator=">=",
             value={"amount": 100, "currency": "EUR"})
    c = ctx(documents={"bank": {"balance": {"amount": 500, "currency": "USD"}}})
    assert threshold(chk, c).verdict == "indeterminate"   # never a pass


def test_threshold_missing_indeterminate():
    chk = mk("threshold", field_path="insurance.coverage_amount", operator=">=",
             value={"amount": 30000, "currency": "EUR"})
    assert threshold(chk, ctx(documents={"insurance": {}})).verdict == "indeterminate"


def test_threshold_date_offset():
    # passport expiry >= flight.return + 3 months (return 2026-09-10 → 2026-12-10)
    chk = mk("threshold", field_path="passport.expiry_date", operator=">=",
             params={"rhs": {"date_offset": {"of": {"context": "flight.return_date"}, "months": 3}}})
    docs = {"flight": {"return_date": "2026-09-10"}}
    assert threshold(chk, ctx(documents={**docs, "passport": {"expiry_date": "2026-12-10"}})).verdict == "pass"
    assert threshold(chk, ctx(documents={**docs, "passport": {"expiry_date": "2026-12-09"}})).verdict == "fail"


def test_date_coverage_gap_boundary():
    chk = mk("date_coverage", params={"a_start": "insurance.coverage_start",
             "a_end": "insurance.coverage_end", "b_start": "flight.departure_date",
             "b_end": "flight.return_date", "tolerance_days": 0})
    flight = {"departure_date": "2026-09-01", "return_date": "2026-09-10"}
    def v(a_end):
        c = ctx(documents={"flight": flight,
                           "insurance": {"coverage_start": "2026-09-01", "coverage_end": a_end}})
        return date_coverage(chk, c).verdict
    assert v("2026-09-10") == "pass"   # 0-day gap
    assert v("2026-09-09") == "fail"   # 1-day gap


def test_set_membership_superset_and_in():
    sup = mk("set_membership", field_path="insurance.territory", value=["IT", "FR"],
             params={"mode": "superset"})
    assert set_membership(sup, ctx(documents={"insurance": {"territory": ["IT", "FR", "DE"]}})).verdict == "pass"
    assert set_membership(sup, ctx(documents={"insurance": {"territory": ["IT"]}})).verdict == "fail"
    inn = mk("set_membership", field_path="bank.insurer", value=["ACME", "GLOBE"])
    assert set_membership(inn, ctx(documents={"bank": {"insurer": "ACME"}})).verdict == "pass"
    assert set_membership(inn, ctx(documents={"bank": {"insurer": "XYZ"}})).verdict == "fail"


def test_presence():
    chk = mk("presence", field_path="insurance.repatriation")
    assert presence(chk, ctx(documents={"insurance": {"repatriation": True}})).verdict == "pass"
    assert presence(chk, ctx(documents={"insurance": {"repatriation": False}})).verdict == "fail"
    assert presence(chk, ctx(documents={"insurance": {}})).verdict == "indeterminate"


def test_cross_document_name_matches():
    chk = mk("cross_document_match", params={"left": "passport.full_name",
             "right": "insurance.holder_name", "match": "name", "min_ratio": 0.85})
    def v(right):
        c = ctx(documents={"passport": {"full_name": "ROHAN KUMAR"},
                           "insurance": {"holder_name": right}})
        return cross_document_match(chk, c).verdict
    assert v("ROHAN KUMAR") == "pass"      # exact
    assert v("ROHAN A KUMAR") == "pass"    # middle initial
    assert v("ROHAN KUMAAR") == "pass"     # 1-char surname typo (near-match)
    assert v("MOHAN KUMAR") == "fail"      # different person, 1-char first-name diff
    assert v("PRIYA SHARMA") == "fail"     # clearly different


def test_cross_document_date_match():
    chk = mk("cross_document_match", params={"left": "flight.return_date",
             "right": "insurance.coverage_end", "match": "exact"})
    same = ctx(documents={"flight": {"return_date": "2026-09-10"},
                          "insurance": {"coverage_end": "2026-09-10"}})
    diff = ctx(documents={"flight": {"return_date": "2026-09-10"},
                          "insurance": {"coverage_end": "2026-09-11"}})
    assert cross_document_match(chk, same).verdict == "pass"
    assert cross_document_match(chk, diff).verdict == "fail"


def test_derived_routing_most_nights_and_tie():
    chk = mk("derived_routing", field_path="trip.itinerary")
    most = TripFacts(itinerary=[{"country": "IT", "nights": 6}, {"country": "FR", "nights": 3}],
                     stated_consulate="IT")
    assert derived_routing(chk, ctx(trip=most)).verdict == "pass"
    wrong = TripFacts(itinerary=most.itinerary, stated_consulate="FR")
    assert derived_routing(chk, ctx(trip=wrong)).verdict == "fail"
    tie = TripFacts(itinerary=[{"country": "IT", "nights": 5}, {"country": "FR", "nights": 5}],
                    stated_consulate="IT")  # tie → first entry IT
    assert derived_routing(chk, ctx(trip=tie)).verdict == "pass"


def test_recency_boundary():
    chk = mk("recency", field_path="bank.statement_date", params={"within_days": 30})
    def v(d):
        return recency(chk, ctx(documents={"bank": {"statement_date": d}}, today=date(2026, 8, 1))).verdict
    assert v("2026-07-02") == "pass"   # exactly 30 days
    assert v("2026-07-01") == "fail"   # 31 days
    assert v("2026-08-05") == "fail"   # future


def test_format_dimensions_and_regex():
    dims = mk("format", field_path="photo.dimensions",
              params={"dimensions": {"width_mm": 35, "height_mm": 45, "tolerance_mm": 0}})
    assert format_check(dims, ctx(documents={"photo": {"dimensions": {"width_mm": 35, "height_mm": 45}}})).verdict == "pass"
    assert format_check(dims, ctx(documents={"photo": {"dimensions": {"width_mm": 30, "height_mm": 40}}})).verdict == "fail"
    assert format_check(dims, ctx(documents={"photo": {}})).verdict == "indeterminate"
    rgx = mk("format", field_path="passport.number", params={"regex": r"[A-Z]\d{7}"})
    assert format_check(rgx, ctx(documents={"passport": {"number": "A1234567"}})).verdict == "pass"
    assert format_check(rgx, ctx(documents={"passport": {"number": "123"}})).verdict == "fail"


if __name__ == "__main__":
    tests = [v for k, v in sorted(globals().items()) if k.startswith("test_")]
    for t in tests:
        t()
        print(f"PASS  {t.__name__}")
    print(f"\nAll {len(tests)} boundary tests passed.")
