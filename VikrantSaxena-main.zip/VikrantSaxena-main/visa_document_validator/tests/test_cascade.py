"""Cascade invalidation (§6 Gap 3): re-upload re-runs EXACTLY the dependent
checks and nothing else."""

from __future__ import annotations

import copy

import _harness  # noqa: F401
from _harness import add_docs, fresh_repo, make_session

from app.engine.orchestrator import reupload_document, run_session_checks
from app.fixtures.eval_cases import BASE_DOCS, BASE_EXPECTED, BASE_TODAY, BASE_TRIP

ALL_KEYS = set(BASE_EXPECTED)
# Depend on 'insurance' = own document is insurance OR insurance in depends_on_documents.
DEP_INSURANCE = {
    "insurance_min_coverage", "insurance_territory", "insurance_repatriation",
    "insurance_date_coverage", "cross_doc_name_match", "cross_doc_date_match",
}


def _setup():
    repo = fresh_repo()
    session = make_session(repo, itinerary=copy.deepcopy(BASE_TRIP))
    add_docs(repo, session, copy.deepcopy(BASE_DOCS))
    run_session_checks(repo, session, today=BASE_TODAY)
    return repo, session


def test_reupload_reruns_exactly_dependent_checks():
    repo, session = _setup()
    before = {r.check_key: r for r in repo.list_results(session.id, include_stale=False)}
    assert set(before) == ALL_KEYS

    new_ins = copy.deepcopy(BASE_DOCS["insurance"])
    new_ins["coverage_amount"] = {"amount": 25000, "currency": "EUR"}   # now fails
    res = reupload_document(repo, session, "insurance", new_ins, today=BASE_TODAY)

    assert res.rerun_keys == DEP_INSURANCE, res.rerun_keys

    # Old dependent results are stale; non-dependent results untouched.
    for k in DEP_INSURANCE:
        assert before[k].stale is True, f"{k} should be stale"
    for k in ALL_KEYS - DEP_INSURANCE:
        assert before[k].stale is False, f"{k} must NOT be touched"

    non_stale = {r.check_key: r for r in repo.list_results(session.id, include_stale=True) if not r.stale}
    assert set(non_stale) == ALL_KEYS
    for k in DEP_INSURANCE:
        assert non_stale[k] is not before[k]          # a fresh result was computed
    for k in ALL_KEYS - DEP_INSURANCE:
        assert non_stale[k] is before[k]              # nothing else re-ran (same object)

    assert non_stale["insurance_min_coverage"].verdict == "fail"   # new value took effect
    assert non_stale["sufficient_means"].verdict == "pass"         # untouched, prior verdict


def test_reupload_flight_dependent_set():
    repo, session = _setup()
    res = reupload_document(repo, session, "flight", copy.deepcopy(BASE_DOCS["flight"]), today=BASE_TODAY)
    assert res.rerun_keys == {"passport_validity", "insurance_date_coverage", "cross_doc_date_match"}


if __name__ == "__main__":
    tests = [v for k, v in sorted(globals().items()) if k.startswith("test_")]
    for t in tests:
        t()
        print(f"PASS  {t.__name__}")
    print(f"\nAll {len(tests)} cascade tests passed.")
