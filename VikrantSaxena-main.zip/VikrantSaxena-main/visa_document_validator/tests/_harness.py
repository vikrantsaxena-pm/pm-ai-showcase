"""Shared test helpers. Not a test module."""

from __future__ import annotations

import os
import sys
from datetime import date, datetime, timezone

_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _ROOT not in sys.path:
    sys.path.insert(0, _ROOT)

from app.engine.models import Session, SessionDocument   # noqa: E402
from app.engine.repository import InMemoryRepository      # noqa: E402
from app.fixtures.schengen import seed                    # noqa: E402


def fresh_repo() -> InMemoryRepository:
    repo = InMemoryRepository()
    seed(repo)
    return repo


def make_session(repo, jurisdiction="schengen/IT", purpose="tourism",
                 planned_visit_date=date(2026, 8, 15), itinerary=None, sid="s1") -> Session:
    now = datetime(2026, 8, 1, tzinfo=timezone.utc)
    s = Session(
        id=sid, jurisdiction=jurisdiction, purpose=purpose,
        planned_visit_date=planned_visit_date, consent_given_at=now, expires_at=now,
        itinerary=itinerary,
    )
    repo.add_session(s)
    return s


def add_docs(repo, session, docs: dict) -> None:
    for dtype, extracted in docs.items():
        repo.add_document(SessionDocument(
            id=None, session_id=session.id, document_type=dtype, extracted=extracted,
        ))
