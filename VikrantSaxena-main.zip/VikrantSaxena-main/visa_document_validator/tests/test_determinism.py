"""Determinism: same inputs → identical verdicts across runs (§10)."""

from __future__ import annotations

import _harness  # noqa: F401
from _harness import add_docs, fresh_repo, make_session

from app.engine.orchestrator import run_session_checks, verdict_map
from app.fixtures.eval_cases import CASES


def _run_all() -> dict[str, dict[str, str]]:
    out = {}
    for case in CASES:
        repo = fresh_repo()
        session = make_session(repo, itinerary=case.trip)
        add_docs(repo, session, case.docs)
        out[case.name] = verdict_map(run_session_checks(repo, session, today=case.today))
    return out


def test_identical_across_runs():
    first = _run_all()
    second = _run_all()
    assert first == second, "non-deterministic verdicts across identical runs"


if __name__ == "__main__":
    tests = [v for k, v in sorted(globals().items()) if k.startswith("test_")]
    for t in tests:
        t()
        print(f"PASS  {t.__name__}")
    print(f"\nAll {len(tests)} determinism tests passed.")
