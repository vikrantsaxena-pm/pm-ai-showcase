"""Run the eval set through the full orchestrator. The quality bar (§10)."""

from __future__ import annotations

import _harness  # noqa: F401 - sets sys.path
from _harness import add_docs, fresh_repo, make_session

from app.engine.orchestrator import run_session_checks, verdict_map
from app.fixtures.eval_cases import CASES


def _run(case) -> dict[str, str]:
    repo = fresh_repo()
    session = make_session(repo, itinerary=case.trip)
    add_docs(repo, session, case.docs)
    return verdict_map(run_session_checks(repo, session, today=case.today))


def test_eval_expected_verdicts():
    failures = []
    for case in CASES:
        vm = _run(case)
        for key, expected in case.expected.items():
            got = vm.get(key)
            if got != expected:
                failures.append(f"{case.name}: {key} expected={expected} got={got}  ({case.why})")
    assert not failures, "eval mismatches:\n  " + "\n  ".join(failures)


def test_zero_false_pass():
    false_passes = []
    for case in CASES:
        vm = _run(case)
        for key, expected in case.expected.items():
            if expected != "pass" and vm.get(key) == "pass":
                false_passes.append(f"{case.name}:{key} (expected {expected})")
    assert not false_passes, "FALSE PASSES (must be zero):\n  " + "\n  ".join(false_passes)


def test_every_primitive_exercised():
    # Sanity: the fixtures cover all 8 primitive types.
    from app.engine.primitives import PRIMITIVES
    from app.fixtures.schengen import _base_checks
    used = {c.check_type for c in _base_checks()}
    assert used == set(PRIMITIVES), f"primitives not all exercised: {set(PRIMITIVES) - used}"


if __name__ == "__main__":
    tests = [v for k, v in sorted(globals().items()) if k.startswith("test_")]
    for t in tests:
        t()
        print(f"PASS  {t.__name__}")
    print(f"\nAll {len(tests)} tests passed. ({len(CASES)} eval cases, 0 false-pass.)")
