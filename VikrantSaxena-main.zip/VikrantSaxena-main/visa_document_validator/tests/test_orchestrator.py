"""Ruleset resolution, inheritance/override, blocked path, no-ruleset, ordering."""

from __future__ import annotations

import copy
from datetime import date

import _harness  # noqa: F401
from _harness import add_docs, fresh_repo, make_session

from app.engine.orchestrator import NoRulesetError, run_session_checks, verdict_map
from app.fixtures.eval_cases import BASE_DOCS, BASE_TODAY, BASE_TRIP


def test_resolves_italy_ruleset():
    repo = fresh_repo()
    rs = repo.resolve_ruleset("schengen/IT", "tourism", date(2026, 8, 15))
    assert rs is not None and rs.id == "rs_it"
    assert len(repo.list_checks(rs.id)) == 11   # inherited base + Italy override


def test_inheritance_override_changes_verdict_no_code():
    # Same applicant, balance €500, 9 nights. Base daily €70 → €630 → fail;
    # Italy override daily €50 → €450 → pass. Zero code change — data only.
    repo = fresh_repo()
    it = make_session(repo, jurisdiction="schengen/IT", itinerary=copy.deepcopy(BASE_TRIP), sid="it")
    add_docs(repo, it, copy.deepcopy(BASE_DOCS))
    assert verdict_map(run_session_checks(repo, it, BASE_TODAY))["sufficient_means"] == "pass"

    base = make_session(repo, jurisdiction="schengen", itinerary=copy.deepcopy(BASE_TRIP), sid="base")
    add_docs(repo, base, copy.deepcopy(BASE_DOCS))
    assert verdict_map(run_session_checks(repo, base, BASE_TODAY))["sufficient_means"] == "fail"


def test_blocked_when_prerequisite_document_missing():
    repo = fresh_repo()
    s = make_session(repo, itinerary=copy.deepcopy(BASE_TRIP))
    docs = copy.deepcopy(BASE_DOCS)
    docs.pop("flight")
    add_docs(repo, s, docs)
    vm = verdict_map(run_session_checks(repo, s, BASE_TODAY))
    assert vm["passport_validity"] == "blocked"
    assert vm["insurance_date_coverage"] == "blocked"
    assert vm["cross_doc_date_match"] == "blocked"
    assert vm["insurance_min_coverage"] == "pass"   # unaffected checks still run


def test_no_ruleset_raises_not_guesses():
    repo = fresh_repo()
    s = make_session(repo, jurisdiction="schengen/XX")
    try:
        run_session_checks(repo, s, BASE_TODAY)
    except NoRulesetError:
        return
    raise AssertionError("expected NoRulesetError for an unknown jurisdiction")


def test_document_requirements_lead_time_order():
    repo = fresh_repo()
    reqs = repo.list_document_requirements("rs_it")
    lead = [r.max_fix_lead_time_days for r in reqs]
    assert lead == sorted(lead, reverse=True)          # §6 Gap 2: longest-lead first
    assert reqs[0].document_type == "bank" and reqs[-1].document_type == "photo"


if __name__ == "__main__":
    tests = [v for k, v in sorted(globals().items()) if k.startswith("test_")]
    for t in tests:
        t()
        print(f"PASS  {t.__name__}")
    print(f"\nAll {len(tests)} orchestrator tests passed.")
