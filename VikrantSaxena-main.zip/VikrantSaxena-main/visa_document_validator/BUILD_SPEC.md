# BUILD_SPEC.md — Visa Document Validator

**This file is authoritative. Read it fully before writing any code. If a request conflicts with an invariant below, stop and flag it.**

---

## 1. What this is

A **visa document validator**. A user tells us their destination, purpose, and planned visa-office date. We list the required documents, verify them one at a time with a comment on each, and produce a final issue summary plus a correctly-foldered ZIP docket.

Behind it, a rules database that a crawler + human review loop keeps current.

**It is not** a filing service, an approval predictor, or a trip planner.

---

## 2. Hard invariants — never violate

1. **The LLM never decides anything.** It does exactly two jobs: (a) extract structured fields from a user's uploaded document, (b) narrate a verdict from computed JSON. Every pass/fail is Python comparing an extracted value to a ratified rule.
2. **The LLM never fetches rules at request time.** Rules come from the database. If the DB has no ruleset, the app says so — it does not guess.
3. **Rules are data, not code.** Adding a jurisdiction = inserting rows. Zero code changes. No threshold, date rule, or list is hard-coded anywhere.
4. **Citations are stored, human-ratified data.** Never generated at request time. A citation points at an immutable source snapshot.
5. **Freshness reads from `last_success_at`, never `last_fetched_at`.** A crawler that runs daily and fails daily must show "last verified 14 days ago."
6. **Never certify approval.** Output is "mechanically compliant on X of Y checkable requirements." Consular judgement (intent to return) is explicitly out of scope and must be stated in the output.
7. **Secondary sources detect; primary sources are truth.** A law-firm alert may trigger a review item. It may never be the citation.
8. **Relaxations never auto-ratify and never pre-stage.** See §7.
9. **Extraction failure ≠ pass.** Low confidence or missing field → `indeterminate`, never `pass`.

---

## 3. Stack

- **API**: FastAPI (Python). This is the product — both UIs are clients of it.
- **DB**: Supabase (Postgres + JSONB + RLS + ap-south-1 for data residency).
- **UIs**: Streamlit — one applicant app, one review console. Reference clients, not the product.
- **LLM**: provider-agnostic via env (`LLM_PROVIDER`, `LLM_MODEL`). Support Claude / OpenAI / Gemini. Never hardcode.
- **Storage**: Supabase Storage for source snapshots (permanent) and session documents (encrypted, TTL-purged).

---

## 4. Architecture — two clocks

**BUILD TIME** (offline, human-in-loop):
```
secondary source (law firm alert, EUR-Lex feed, gov press)
  → crawler detects change → change_queue item (DETECTION ONLY)
  → human claims item
  → human opens OFFICIAL page, captures URL + PDF snapshot + hash   ← REQUIRED
  → LLM drafts rule JSON from the captured snapshot
  → strictness triage: stricter → may auto-ratify | relaxation → human
  → ratified → rulesets/checks rows, effective-dated
```

**REQUEST TIME** (online):
```
session: jurisdiction + purpose + planned_visit_date
  → resolve ruleset WHERE effective_from <= planned_visit_date
                      AND (effective_to IS NULL OR effective_to > planned_visit_date)
                      AND status = 'in_force'
  → list document_requirements ORDERED BY max_fix_lead_time_days DESC   ← §6 Gap 2
  → user uploads → LLM extracts → Python evaluates → citation from rule row → LLM narrates
```

**Not RAG.** The question space is finite (~14 checks per visa type). Compile ahead, execute deterministically. RAG is P2, for free-text Q&A only.

---

## 5. Schema

```sql
-- ── SOURCES ────────────────────────────────────────────────
create table sources (
  id uuid primary key default gen_random_uuid(),
  jurisdiction text not null,              -- 'schengen/IT'
  tier int not null,                       -- 0 | 1 | 2
  role text not null check (role in ('primary','secondary')),
  url text not null,
  content_selector text,                   -- strips nav/banners
  fetch_frequency interval not null,       -- tier2: 1d, tier1: 7d, tier0: 30d
  last_fetched_at timestamptz,
  last_success_at timestamptz,             -- FRESHNESS READS THIS
  last_hash text,
  consecutive_failures int not null default 0,
  status text not null default 'active'    -- active | degraded | dead
);

-- ── IMMUTABLE EVIDENCE ─────────────────────────────────────
create table source_snapshots (
  id uuid primary key default gen_random_uuid(),
  source_id uuid references sources(id),
  official_url text not null,              -- REQUIRED, even for manual capture
  storage_path text not null,              -- the captured PDF/HTML
  content_hash text not null,
  captured_at timestamptz not null default now(),
  captured_by uuid                         -- null = crawler, else employee
);

-- ── RULES ──────────────────────────────────────────────────
create table rulesets (
  id uuid primary key default gen_random_uuid(),
  jurisdiction text not null,
  visa_type text not null,                 -- 'schengen_c'
  purpose text not null,                   -- tourism | business | family_visit
  version int not null,
  parent_ruleset_id uuid references rulesets(id),   -- inheritance: schengen_base
  announced_at date,
  effective_from date not null,
  effective_to date,
  status text not null,                    -- see §7 state machine
  source_snapshot_id uuid references source_snapshots(id),
  implementation_verified_at timestamptz,
  last_verified_at timestamptz,
  ratified_by uuid,
  ratified_at timestamptz,
  created_at timestamptz not null default now()
);

create table checks (
  id uuid primary key default gen_random_uuid(),
  ruleset_id uuid references rulesets(id) on delete cascade,
  check_key text not null,                 -- 'insurance_min_coverage'
  check_type text not null,                -- one of the 8 primitives
  field_path text not null,                -- 'insurance.coverage_amount'
  operator text,
  value jsonb,
  params jsonb,
  citation jsonb not null,                 -- {snapshot_id, clause, page}
  severity text not null,
  fix_lead_time_days int not null,         -- DRIVES ordering + report sort
  document_type text,                      -- which doc satisfies this
  depends_on_documents text[]              -- for cross_document_match
);

create table document_requirements (
  id uuid primary key default gen_random_uuid(),
  ruleset_id uuid references rulesets(id) on delete cascade,
  document_type text not null,
  display_name text not null,
  required boolean not null default true,
  max_fix_lead_time_days int not null,     -- ORDERING KEY, desc
  folder_name text not null                -- for the ZIP docket
);

-- ── SESSIONS ───────────────────────────────────────────────
create table sessions (
  id uuid primary key default gen_random_uuid(),
  jurisdiction text not null,
  purpose text not null,                   -- §6 Gap 1
  planned_visit_date date not null,        -- THE forward-looking key
  itinerary jsonb,                         -- nights per country
  derived_consulate text,
  ruleset_id uuid references rulesets(id),
  consent_given_at timestamptz not null,   -- DPDPA
  expires_at timestamptz not null,         -- TTL purge
  status text not null default 'active',
  created_at timestamptz not null default now()
);

create table session_documents (
  id uuid primary key default gen_random_uuid(),
  session_id uuid references sessions(id) on delete cascade,
  document_type text not null,
  storage_path text,                       -- encrypted; purged at expires_at
  extracted jsonb,
  extraction_confidence float,
  superseded_by uuid references session_documents(id),  -- re-upload chain
  uploaded_at timestamptz not null default now(),
  status text not null default 'uploaded'  -- uploaded | skipped | superseded
);

create table check_results (
  id uuid primary key default gen_random_uuid(),
  session_id uuid references sessions(id) on delete cascade,
  check_id uuid references checks(id),
  document_id uuid references session_documents(id),
  verdict text not null,                   -- pass | fail | indeterminate | blocked
  extracted_value jsonb,
  expected_value jsonb,
  narrative text,
  stale boolean not null default false,    -- §6 Gap 3 cascade
  computed_at timestamptz not null default now()
);

-- ── CHANGE QUEUE ───────────────────────────────────────────
create table change_queue (
  id uuid primary key default gen_random_uuid(),
  jurisdiction text not null,
  detected_at timestamptz not null default now(),
  detected_by_source_id uuid references sources(id),
  signal_summary text,
  proposed_diff jsonb,
  target_effective_from date,              -- from the announcement
  claimed_by uuid,                         -- SHARED QUEUE + CLAIM LOCK
  claimed_at timestamptz,
  status text not null default 'detected', -- see §7
  investigation_deadline date,             -- CAPPED, see §7
  suppression_hash text,                   -- rejected → don't re-fire
  resolved_at timestamptz,
  resolved_by uuid
);
```

**Audit rule:** `check_results` and `sessions` are the audit trail. Never store raw documents beyond `expires_at`.

---

## 6. Customer journey (with required fixes)

```
1. Ask: destination + purpose + planned_visit_date + itinerary
   ⚠ PURPOSE IS REQUIRED — document list depends on it
2. Derive consulate (most-nights rule; tie → country of first entry)
   → surface as first finding, WITH citation, before any upload
3. List required documents ORDERED BY max_fix_lead_time_days DESC
   ⚠ Bank statement / employment letter FIRST. Photo LAST.
   Reason: 8-week fixes must surface in minute 2, not upload 7.
4. Upload → extract → evaluate → narrate → ask for next (same reply)
   - [Re-upload] button under every verdict
   - [I don't have this yet] → mark skipped, keep session alive
5. Summary: all issues, grouped by fix lead time:
   "Fix today (1-2d)" / "Start now (4-8w)" / "Cannot assess"
6. ZIP docket: foldered per document_requirements.folder_name
```

**Gap fixes that must be implemented:**

- **Gap 1 — purpose input.** Required at session start.
- **Gap 2 — lead-time ordering.** Upload sequence AND report sort by `fix_lead_time_days` desc. Not conventional checklist order.
- **Gap 3 — cascade invalidation.** On re-upload, mark `stale=true` on every `check_result` whose check has the re-uploaded doc in `depends_on_documents`, then re-run them. A re-uploaded insurance invalidates insurance↔flight date checks.
- **Gap 4 — skip path.** "Don't have it yet" keeps the session alive, marks pending, excludes from ZIP.
- **Gap 5 — checklist panel.** Streamlit sidebar showing every requirement + state. Chat cannot answer "what's left?".

**Storage decision (locked):** documents stored **encrypted at rest with a hard TTL** (`sessions.expires_at`, default 30 days) and explicit consent captured at session start. Rationale: the 4–8 week fix cycle makes in-memory-only unworkable, and the ZIP needs all documents. A purge job must actually run — write it in Phase 2, not later.

---

## 7. State machines

### Ruleset status
```
draft
  → ratified_scheduled   (approved, effective_from in future) → fires automatically
  → in_force
  → superseded

announced_pending        ← announced but NOT confirmed in force. NEVER FIRES.
                           (Germany announced ATV removal Jan 2026; still not in
                            force in July 2026. Firing early = telling users a
                            requirement is gone when it isn't.)
pending_implementation   ← effective_from passed, implementation unverified.
                           NEVER FIRES. Recurring re-check, not one-time.
rolled_back              ← fired, didn't land, reverted.
```

**T+1 rule:** the day after `effective_from`, auto-create a verification task. Unverified at T+7 → roll back to prior ruleset + flag.

### Strictness asymmetry (Gap: auto-ratify safely)
```
Is the change STRICTER or ADDITIVE?  → may auto-ratify (if multi-model consensus
                                        AND citation verified in snapshot)
Is it a RELAXATION or REMOVAL?       → HUMAN ONLY. Never pre-stage.
```
Rationale: wrong-toward-strict costs the user a pricier policy. Wrong-toward-loose costs them the trip. Two orders of magnitude apart.

All auto-ratified changes appear in a mandatory weekly human review list.

### Change queue status
```
detected → claimed → { ratified | rejected_suppressed | investigating }
                                          ↑
                          suppression_hash set; do not re-queue
                          until source hash changes AGAIN
investigating → (deadline) → ratified | rejected_suppressed
```

**Deadline cap (Gap 6 — enforce in code):**
```
investigation_deadline < target_effective_from - buffer(3 days)
```
The employee **cannot** set a deadline past the rule's effective date. If they try, reject the input. Otherwise you serve a known-wrong rule.

**Reminders (shared queue model):**
- Unclaimed items broadcast to **all employees**; anyone may claim.
- Claim locks the item (`claimed_by`, `claimed_at`) — prevents duplicate work and creates accountability.
- Claim auto-expires after 48h of inactivity → returns to the pool.
- If an item passes `target_effective_from` unresolved → **auto-degrade that jurisdiction**: `sources.status='degraded'` → user-facing staleness warning fires automatically.

The reminder must connect to the user-facing honesty surface. An ignored queue must become visible to users, not just noisy internally.

---

## 8. Check primitives (the engine is universal)

| type | semantics |
|---|---|
| `threshold` | extracted `op` value (>=, <=, ==). Currency-aware. |
| `date_coverage` | range A must fully cover range B. `tolerance_days` param (Schengen = 0). |
| `set_membership` | extracted value ∈ allowed set (e.g. all 29 Schengen states; approved insurers). |
| `presence` | field/document exists and is non-empty. |
| `cross_document_match` | field X in doc A == field Y in doc B (fuzzy for names). |
| `derived_routing` | compute from itinerary (most-nights consulate). |
| `recency` | document dated within N days of today. |
| `format` | regex / dimension / spec match (photo). |

Each returns `pass | fail | indeterminate`, plus extracted value, expected value, and the citation from its rule row.

---

## 9. Seed data (Phase 0)

Seed `schengen_base` from the EU Visa Code + **one** consulate delta (Italy). Minimum checks:

- `insurance_min_coverage` — threshold, ≥ €30,000
- `insurance_territory` — set_membership, all 29 Schengen states
- `insurance_repatriation` — presence
- `insurance_date_coverage` — date_coverage, tolerance_days = 0
- `passport_validity` — threshold, ≥ 3 months beyond return
- `consulate_routing` — derived_routing, most-nights
- `sufficient_means` — threshold, balance ≥ days × daily_requirement
- `cross_doc_name_match` — cross_document_match
- `cross_doc_date_match` — cross_document_match

Every seeded check **must** carry a real citation to a captured snapshot. **Do not invent clause numbers.** If the clause can't be located in the snapshot, leave the check unratified and flag it.

---

## 10. Testing (non-negotiable)

- **Eval set first.** Before any UI: fixtures of known-good and known-bad documents with hand-verified expected verdicts. This is the quality bar.
- **Target: 0% false-pass on the eval set.** A false "you're fine" costs the user their trip.
- Boundary tests on every primitive (€29,999 / €30,000 / €30,001; 0-day gap; 1-day gap).
- Orchestration tests offline (no LLM calls).
- Determinism test: same inputs → identical verdict across runs.
- Cascade test: re-upload invalidates and re-runs exactly the dependent checks.
- Deadline-cap test: setting `investigation_deadline` past `target_effective_from` is rejected.

---

## 11. Conventions

- Pinned `requirements.txt`. `.env.example` with placeholders, never real keys.
- Every module gets tests. Never claim done without running it.
- Click through real flows — a health check proving the app boots is not proof the flow works.
- Provider-agnostic LLM access in one module (`providers.py`).
